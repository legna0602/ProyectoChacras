package com.Proyectochacras.FoodOrganic.repositories;

public interface ClienteRepository {
}
