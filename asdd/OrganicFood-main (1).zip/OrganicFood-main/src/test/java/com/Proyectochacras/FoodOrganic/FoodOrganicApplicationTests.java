package com.Proyectochacras.FoodOrganic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodOrganicApplicationTests {

	@Test
	void contextLoads() {
	}

}
