package com.Proyectochacras.FoodOrganic.models;

public enum Rol {
    USUARIO,
    ADMINISTRADOR
}
