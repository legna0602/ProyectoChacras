package com.Proyectochacras.FoodOrganic.models;

public enum EstadoChacra {
    DISPONIBLE,
    OCUPADO
}
