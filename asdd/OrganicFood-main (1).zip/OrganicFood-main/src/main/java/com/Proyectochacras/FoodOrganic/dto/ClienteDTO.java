package com.Proyectochacras.FoodOrganic.dto;

public class ClienteDTO {
}
