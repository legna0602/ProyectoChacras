## **Organic Food**
Un proyecto para mi carrera Tecnicatura en Desarrollo de Software , que consiste en:
Cada productor de una chacra de Tierra del Fuego, Rio Grande puede publicar sus Productos a travez de un sistema de oferta - demanda 

¿Quien puede ver los publicaciones?
Las publicaciones lo pueden ver todas las personas interesadas en el sistema gratuito, se va a ver las chacras que estan disponibles , la ubicacion , y si ese productor que vende Productos organicos si se dirige a una feria de la localidad,para vender dichos productos como Lechuga, Tomate, Papas, Zapallo va a ser anunciado por un anuncio.

  ***¿Que Herramientas utilize?***
  

 - JAVA
 - Spring Boot
 - SQL
 - Autenticacion - Autorizacion 
 - Script de contraseñas 
 - HTML - CSS - JS


  
